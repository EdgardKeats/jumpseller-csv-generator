package cl.rivendel.csv.model.imgbb;

public class ImgBBImage {
    private String filename;
    private String name;
    private String mime;
    private String extension;
    private String url;

    public ImgBBImage() {
    }

    public ImgBBImage(String filename, String name, String mime, String extension, String url) {
        this.filename = filename;
        this.name = name;
        this.mime = mime;
        this.extension = extension;
        this.url = url;
    }

    public String getFilename() {
        return filename;
    }

    public void setFilename(String filename) {
        this.filename = filename;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMime() {
        return mime;
    }

    public void setMime(String mime) {
        this.mime = mime;
    }

    public String getExtension() {
        return extension;
    }

    public void setExtension(String extension) {
        this.extension = extension;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
